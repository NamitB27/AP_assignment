To run the code properly using maven, enter the following on the Terminal in the folder named As_2
1. mvn clean
2. mvn compile
3. mvn package
4. cd target
5. java -jar As_2-1.0-SNAPSHOT.jar
6. the code is working